const Spinner = () => `
  <div class="loader"></div>
`

export default Spinner
